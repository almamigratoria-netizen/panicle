import Geom2 from './type'

export default reverse

declare function reverse(geometry: Geom2): Geom2
