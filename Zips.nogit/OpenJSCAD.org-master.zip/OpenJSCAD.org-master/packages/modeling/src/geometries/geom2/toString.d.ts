import Geom2 from './type'

export default toString

declare function toString(geometry: Geom2): string
