export default validate

declare function validate(object: any): void
