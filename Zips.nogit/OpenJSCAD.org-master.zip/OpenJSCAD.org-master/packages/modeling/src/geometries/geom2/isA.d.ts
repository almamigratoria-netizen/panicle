import Geom2 from './type'

export default isA

declare function isA(object: any): object is Geom2
