import Geom3 from './type'

export default clone

declare function clone(geometry: Geom3): Geom3
