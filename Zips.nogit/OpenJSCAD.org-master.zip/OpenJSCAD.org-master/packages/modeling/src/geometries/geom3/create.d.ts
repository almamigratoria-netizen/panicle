import Geom3 from './type'
import Poly3 from '../poly3/type'

export default create

declare function create(polygons?: Array<Poly3>): Geom3
