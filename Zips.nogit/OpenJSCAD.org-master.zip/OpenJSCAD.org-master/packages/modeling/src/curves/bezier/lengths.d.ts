import Bezier from './type'

export default lengths

declare function lengths(segments: number, bezier: Bezier): Array<number>