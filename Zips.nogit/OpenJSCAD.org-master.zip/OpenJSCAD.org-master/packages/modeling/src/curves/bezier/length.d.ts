import Bezier from './type'

export default length

declare function length(segments: number, bezier: Bezier): number