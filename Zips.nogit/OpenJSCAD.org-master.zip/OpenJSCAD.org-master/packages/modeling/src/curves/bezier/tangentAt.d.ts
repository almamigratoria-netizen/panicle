import Bezier from './type'

export default tangentAt

declare function tangentAt(t: number, bezier: Bezier): Array<number> | number
