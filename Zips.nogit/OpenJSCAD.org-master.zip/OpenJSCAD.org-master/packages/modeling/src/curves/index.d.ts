export * as bezier from './bezier'

export as namespace curves
