import { RGB } from './types'

export default colorNameToRgb

declare function colorNameToRgb(s: string): RGB
