module.exports = {
  getFileExtensionFromString: require('./getFileExtensionFromString'),
  version: require('./version')
}
