const json = require('../../package.json')
const version = json.version
module.exports = { version }
