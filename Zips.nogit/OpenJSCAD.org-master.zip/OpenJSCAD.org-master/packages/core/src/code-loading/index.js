module.exports = {
  makeFakeFs: require('./makeFakeFs.js'),
  requireDesignUtilsFs: require('./requireDesignUtilsFs')
}
