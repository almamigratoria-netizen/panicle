module.exports = {
  walkFileTree: require('./walkFileTree')
}
