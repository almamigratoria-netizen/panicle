function Range (begin, step, end) {
  this.begin = begin
  this.step = step
  this.end = end
}

module.exports = Range
