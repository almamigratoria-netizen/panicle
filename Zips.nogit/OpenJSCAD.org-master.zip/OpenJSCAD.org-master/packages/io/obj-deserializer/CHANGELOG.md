# Change Log

All notable changes to this project will be documented in this file.
See [Conventional Commits](https://conventionalcommits.org) for commit guidelines.

## [2.0.30](https://github.com/jscad/OpenJSCAD.org/compare/@jscad/obj-deserializer@2.0.29...@jscad/obj-deserializer@2.0.30) (2024-12-29)

**Note:** Version bump only for package @jscad/obj-deserializer





## [2.0.29](https://github.com/jscad/OpenJSCAD.org/compare/@jscad/obj-deserializer@2.0.28...@jscad/obj-deserializer@2.0.29) (2024-11-10)

**Note:** Version bump only for package @jscad/obj-deserializer





## [2.0.28](https://github.com/jscad/OpenJSCAD.org/compare/@jscad/obj-deserializer@2.0.27...@jscad/obj-deserializer@2.0.28) (2024-10-06)

**Note:** Version bump only for package @jscad/obj-deserializer





## [2.0.27](https://github.com/jscad/OpenJSCAD.org/compare/@jscad/obj-deserializer@2.0.26...@jscad/obj-deserializer@2.0.27) (2024-06-02)

**Note:** Version bump only for package @jscad/obj-deserializer





## [2.0.26](https://github.com/jscad/OpenJSCAD.org/compare/@jscad/obj-deserializer@2.0.25...@jscad/obj-deserializer@2.0.26) (2024-02-18)

**Note:** Version bump only for package @jscad/obj-deserializer





## [2.0.25](https://github.com/jscad/OpenJSCAD.org/compare/@jscad/obj-deserializer@2.0.24...@jscad/obj-deserializer@2.0.25) (2023-06-27)

**Note:** Version bump only for package @jscad/obj-deserializer





## [2.0.24](https://github.com/jscad/OpenJSCAD.org/compare/@jscad/obj-deserializer@2.0.23...@jscad/obj-deserializer@2.0.24) (2023-04-30)

**Note:** Version bump only for package @jscad/obj-deserializer





## [2.0.23](https://github.com/jscad/OpenJSCAD.org/compare/@jscad/obj-deserializer@2.0.22...@jscad/obj-deserializer@2.0.23) (2022-11-26)

**Note:** Version bump only for package @jscad/obj-deserializer





## [2.0.22](https://github.com/jscad/OpenJSCAD.org/compare/@jscad/obj-deserializer@2.0.21...@jscad/obj-deserializer@2.0.22) (2022-08-21)

**Note:** Version bump only for package @jscad/obj-deserializer





## [2.0.21](https://github.com/jscad/OpenJSCAD.org/compare/@jscad/obj-deserializer@2.0.20...@jscad/obj-deserializer@2.0.21) (2022-07-17)

**Note:** Version bump only for package @jscad/obj-deserializer





## [2.0.20](https://github.com/jscad/OpenJSCAD.org/compare/@jscad/obj-deserializer@2.0.19...@jscad/obj-deserializer@2.0.20) (2022-06-12)

**Note:** Version bump only for package @jscad/obj-deserializer





## [2.0.19](https://github.com/jscad/OpenJSCAD.org/compare/@jscad/obj-deserializer@2.0.18...@jscad/obj-deserializer@2.0.19) (2022-05-15)

**Note:** Version bump only for package @jscad/obj-deserializer





## [2.0.18](https://github.com/jscad/OpenJSCAD.org/compare/@jscad/obj-deserializer@2.0.17...@jscad/obj-deserializer@2.0.18) (2022-04-24)

**Note:** Version bump only for package @jscad/obj-deserializer





## [2.0.17](https://github.com/jscad/OpenJSCAD.org/compare/@jscad/obj-deserializer@2.0.16...@jscad/obj-deserializer@2.0.17) (2022-04-03)

**Note:** Version bump only for package @jscad/obj-deserializer





## [2.0.16](https://github.com/jscad/OpenJSCAD.org/compare/@jscad/obj-deserializer@2.0.15...@jscad/obj-deserializer@2.0.16) (2022-04-03)

**Note:** Version bump only for package @jscad/obj-deserializer





## [2.0.15](https://github.com/jscad/OpenJSCAD.org/compare/@jscad/obj-deserializer@2.0.14...@jscad/obj-deserializer@2.0.15) (2022-03-13)

**Note:** Version bump only for package @jscad/obj-deserializer





## [2.0.14](https://github.com/jscad/OpenJSCAD.org/compare/@jscad/obj-deserializer@2.0.13...@jscad/obj-deserializer@2.0.14) (2022-03-06)

**Note:** Version bump only for package @jscad/obj-deserializer





## [2.0.13](https://github.com/jscad/OpenJSCAD.org/compare/@jscad/obj-deserializer@2.0.12...@jscad/obj-deserializer@2.0.13) (2022-02-19)

**Note:** Version bump only for package @jscad/obj-deserializer





## [2.0.12](https://github.com/jscad/OpenJSCAD.org/compare/@jscad/obj-deserializer@2.0.11...@jscad/obj-deserializer@2.0.12) (2021-12-26)

**Note:** Version bump only for package @jscad/obj-deserializer





## [2.0.11](https://github.com/jscad/OpenJSCAD.org/compare/@jscad/obj-deserializer@2.0.10...@jscad/obj-deserializer@2.0.11) (2021-12-11)

**Note:** Version bump only for package @jscad/obj-deserializer





## [2.0.10](https://github.com/jscad/OpenJSCAD.org/compare/@jscad/obj-deserializer@2.0.9...@jscad/obj-deserializer@2.0.10) (2021-11-07)

**Note:** Version bump only for package @jscad/obj-deserializer





## [2.0.9](https://github.com/jscad/OpenJSCAD.org/compare/@jscad/obj-deserializer@2.0.8...@jscad/obj-deserializer@2.0.9) (2021-10-17)

**Note:** Version bump only for package @jscad/obj-deserializer





## [2.0.8](https://github.com/jscad/OpenJSCAD.org/compare/@jscad/obj-deserializer@2.0.7...@jscad/obj-deserializer@2.0.8) (2021-10-04)

**Note:** Version bump only for package @jscad/obj-deserializer





## [2.0.7](https://github.com/jscad/OpenJSCAD.org/compare/@jscad/obj-deserializer@2.0.6...@jscad/obj-deserializer@2.0.7) (2021-09-27)

**Note:** Version bump only for package @jscad/obj-deserializer





## [2.0.6](https://github.com/jscad/OpenJSCAD.org/compare/@jscad/obj-deserializer@2.0.5...@jscad/obj-deserializer@2.0.6) (2021-09-09)

**Note:** Version bump only for package @jscad/obj-deserializer





## [2.0.5](https://github.com/jscad/OpenJSCAD.org/compare/@jscad/obj-deserializer@2.0.4...@jscad/obj-deserializer@2.0.5) (2021-06-20)

**Note:** Version bump only for package @jscad/obj-deserializer





## [2.0.4](https://github.com/jscad/OpenJSCAD.org/compare/@jscad/obj-deserializer@2.0.3...@jscad/obj-deserializer@2.0.4) (2021-06-11)

**Note:** Version bump only for package @jscad/obj-deserializer





## [2.0.3](https://github.com/jscad/OpenJSCAD.org/compare/@jscad/obj-deserializer@2.0.2...@jscad/obj-deserializer@2.0.3) (2021-06-01)

**Note:** Version bump only for package @jscad/obj-deserializer





## [2.0.2](https://github.com/jscad/OpenJSCAD.org/compare/@jscad/obj-deserializer@2.0.0-alpha.0...@jscad/obj-deserializer@2.0.2) (2021-04-20)


### Bug Fixes

* **all:** V2 : several fixes for modeling ([#705](https://github.com/jscad/OpenJSCAD.org/issues/705)) ([62017a4](https://github.com/jscad/OpenJSCAD.org/commit/62017a41214169d6e000f1e0c11aaefdd68e1097))





## [2.0.1](https://github.com/jscad/OpenJSCAD.org/compare/@jscad/obj-deserializer@2.0.0-alpha.0...@jscad/obj-deserializer@2.0.1) (2021-04-15)


### Bug Fixes

* **all:** V2 : several fixes for modeling ([#705](https://github.com/jscad/OpenJSCAD.org/issues/705)) ([62017a4](https://github.com/jscad/OpenJSCAD.org/commit/62017a41214169d6e000f1e0c11aaefdd68e1097))





# [2.0.0](https://github.com/jscad/OpenJSCAD.org/compare/@jscad/obj-deserializer@2.0.0-alpha.11...@jscad/obj-deserializer@2.0.0) (2021-04-12)

**Note:** Version bump only for package @jscad/obj-deserializer





# [2.0.0-alpha.11](https://github.com/jscad/OpenJSCAD.org/compare/@jscad/obj-deserializer@2.0.0-alpha.10...@jscad/obj-deserializer@2.0.0-alpha.11) (2021-03-07)

**Note:** Version bump only for package @jscad/obj-deserializer





# [2.0.0-alpha.10](https://github.com/jscad/OpenJSCAD.org/compare/@jscad/obj-deserializer@2.0.0-alpha.9...@jscad/obj-deserializer@2.0.0-alpha.10) (2021-02-07)

**Note:** Version bump only for package @jscad/obj-deserializer





# [2.0.0-alpha.9](https://github.com/jscad/OpenJSCAD.org/compare/@jscad/obj-deserializer@2.0.0-alpha.8...@jscad/obj-deserializer@2.0.0-alpha.9) (2021-01-02)

**Note:** Version bump only for package @jscad/obj-deserializer





# [2.0.0-alpha.8](https://github.com/jscad/OpenJSCAD.org/compare/@jscad/obj-deserializer@2.0.0-alpha.7...@jscad/obj-deserializer@2.0.0-alpha.8) (2020-12-04)

**Note:** Version bump only for package @jscad/obj-deserializer





# [2.0.0-alpha.7](https://github.com/jscad/OpenJSCAD.org/compare/@jscad/obj-deserializer@2.0.0-alpha.6...@jscad/obj-deserializer@2.0.0-alpha.7) (2020-11-07)

**Note:** Version bump only for package @jscad/obj-deserializer





# [2.0.0-alpha.6](https://github.com/jscad/OpenJSCAD.org/compare/@jscad/obj-deserializer@2.0.0-alpha.5...@jscad/obj-deserializer@2.0.0-alpha.6) (2020-10-11)


### Bug Fixes

* **all:** V2 : several fixes for modeling ([#705](https://github.com/jscad/OpenJSCAD.org/issues/705)) ([62017a4](https://github.com/jscad/OpenJSCAD.org/commit/62017a41214169d6e000f1e0c11aaefdd68e1097))





# [2.0.0-alpha.5](https://github.com/jscad/OpenJSCAD.org/compare/@jscad/obj-deserializer@2.0.0-alpha.4...@jscad/obj-deserializer@2.0.0-alpha.5) (2020-09-29)

**Note:** Version bump only for package @jscad/obj-deserializer





# [2.0.0-alpha.4](https://github.com/jscad/OpenJSCAD.org/compare/@jscad/obj-deserializer@2.0.0-alpha.3...@jscad/obj-deserializer@2.0.0-alpha.4) (2020-09-28)

**Note:** Version bump only for package @jscad/obj-deserializer





# [2.0.0-alpha.3](https://github.com/jscad/OpenJSCAD.org/compare/@jscad/obj-deserializer@2.0.0-alpha.2...@jscad/obj-deserializer@2.0.0-alpha.3) (2020-09-19)

**Note:** Version bump only for package @jscad/obj-deserializer





# [2.0.0-alpha.2](https://github.com/jscad/OpenJSCAD.org/compare/@jscad/obj-deserializer@2.0.0-alpha.1...@jscad/obj-deserializer@2.0.0-alpha.2) (2020-09-08)

**Note:** Version bump only for package @jscad/obj-deserializer





# [2.0.0-alpha.1](https://github.com/jscad/OpenJSCAD.org/compare/@jscad/obj-deserializer@2.0.0-alpha.0...@jscad/obj-deserializer@2.0.0-alpha.1) (2020-08-19)

**Note:** Version bump only for package @jscad/obj-deserializer





# 2.0.0-alpha.0 (2020-08-13)


### Bug Fixes

* **obj-deserializer:** corrected stringify() to supply V2 require and export ([#497](https://github.com/jscad/OpenJSCAD.org/issues/497)) ([1fd11ae](https://github.com/jscad/OpenJSCAD.org/commit/1fd11aeb1e1a309a3b87dd542d43870bceb9c903))





### Features

* **obj-deserializer:** overhaul for V2 branch (#469)
* **io:** change api to deserialize(options, source)

<a name="0.2.3"></a>
## [0.2.3](https://github.com/jscad/io/compare/@jscad/obj-deserializer@0.2.2...@jscad/obj-deserializer@0.2.3) (2018-11-25)




**Note:** Version bump only for package @jscad/obj-deserializer

<a name="0.2.2"></a>
## [0.2.2](https://github.com/jscad/io/compare/@jscad/obj-deserializer@0.2.1...@jscad/obj-deserializer@0.2.2) (2018-11-22)




**Note:** Version bump only for package @jscad/obj-deserializer

<a name="0.2.1"></a>
## [0.2.1](https://github.com/jscad/io/compare/@jscad/obj-deserializer@0.2.0...@jscad/obj-deserializer@0.2.1) (2017-12-14)




**Note:** Version bump only for package @jscad/obj-deserializer

<a name="0.2.0"></a>
# [0.2.0](https://github.com/jscad/io/compare/@jscad/obj-deserializer@0.1.0...@jscad/obj-deserializer@0.2.0) (2017-11-29)


### Features

* add support for a status callback for de/serialization progress ([#49](https://github.com/jscad/io/issues/49)) ([f457cdb](https://github.com/jscad/io/commit/f457cdb))




<a name="0.1.0"></a>
# [0.1.0](https://github.com/jscad/io/compare/@jscad/obj-deserializer@0.0.4...@jscad/obj-deserializer@0.1.0) (2017-11-14)


### Features

* **deserializers:** added csg output capabilities to amf & obj deserializers & basic tests ([#47](https://github.com/jscad/io/issues/47)) ([abf3040](https://github.com/jscad/io/commit/abf3040))




<a name="0.0.4"></a>
## [0.0.4](https://github.com/jscad/io/compare/@jscad/obj-deserializer@0.0.3...@jscad/obj-deserializer@0.0.4) (2017-11-04)




**Note:** Version bump only for package @jscad/obj-deserializer

<a name="0.0.3"></a>
## [0.0.3](https://github.com/jscad/io/compare/@jscad/obj-deserializer@0.0.2...@jscad/obj-deserializer@0.0.3) (2017-10-10)




**Note:** Version bump only for package @jscad/obj-deserializer

<a name="0.0.2"></a>
## 0.0.2 (2017-10-10)




**Note:** Version bump only for package @jscad/obj-deserializer
