# Change Log

All notable changes to this project will be documented in this file.
See [Conventional Commits](https://conventionalcommits.org) for commit guidelines.

## [2.1.27](https://github.com/jscad/OpenJSCAD.org/compare/@jscad/stl-deserializer@2.1.26...@jscad/stl-deserializer@2.1.27) (2024-12-29)

**Note:** Version bump only for package @jscad/stl-deserializer





## [2.1.26](https://github.com/jscad/OpenJSCAD.org/compare/@jscad/stl-deserializer@2.1.25...@jscad/stl-deserializer@2.1.26) (2024-11-10)

**Note:** Version bump only for package @jscad/stl-deserializer





## [2.1.25](https://github.com/jscad/OpenJSCAD.org/compare/@jscad/stl-deserializer@2.1.24...@jscad/stl-deserializer@2.1.25) (2024-10-06)

**Note:** Version bump only for package @jscad/stl-deserializer





## [2.1.24](https://github.com/jscad/OpenJSCAD.org/compare/@jscad/stl-deserializer@2.1.23...@jscad/stl-deserializer@2.1.24) (2024-06-02)

**Note:** Version bump only for package @jscad/stl-deserializer





## [2.1.23](https://github.com/jscad/OpenJSCAD.org/compare/@jscad/stl-deserializer@2.1.22...@jscad/stl-deserializer@2.1.23) (2024-02-18)

**Note:** Version bump only for package @jscad/stl-deserializer





## [2.1.22](https://github.com/jscad/OpenJSCAD.org/compare/@jscad/stl-deserializer@2.1.21...@jscad/stl-deserializer@2.1.22) (2023-06-27)

**Note:** Version bump only for package @jscad/stl-deserializer





## [2.1.21](https://github.com/jscad/OpenJSCAD.org/compare/@jscad/stl-deserializer@2.1.20...@jscad/stl-deserializer@2.1.21) (2023-04-30)

**Note:** Version bump only for package @jscad/stl-deserializer





## [2.1.20](https://github.com/jscad/OpenJSCAD.org/compare/@jscad/stl-deserializer@2.1.19...@jscad/stl-deserializer@2.1.20) (2022-11-26)

**Note:** Version bump only for package @jscad/stl-deserializer





## [2.1.19](https://github.com/jscad/OpenJSCAD.org/compare/@jscad/stl-deserializer@2.1.18...@jscad/stl-deserializer@2.1.19) (2022-08-21)

**Note:** Version bump only for package @jscad/stl-deserializer





## [2.1.18](https://github.com/jscad/OpenJSCAD.org/compare/@jscad/stl-deserializer@2.1.17...@jscad/stl-deserializer@2.1.18) (2022-07-17)

**Note:** Version bump only for package @jscad/stl-deserializer





## [2.1.17](https://github.com/jscad/OpenJSCAD.org/compare/@jscad/stl-deserializer@2.1.16...@jscad/stl-deserializer@2.1.17) (2022-06-12)

**Note:** Version bump only for package @jscad/stl-deserializer





## [2.1.16](https://github.com/jscad/OpenJSCAD.org/compare/@jscad/stl-deserializer@2.1.15...@jscad/stl-deserializer@2.1.16) (2022-05-15)

**Note:** Version bump only for package @jscad/stl-deserializer





## [2.1.15](https://github.com/jscad/OpenJSCAD.org/compare/@jscad/stl-deserializer@2.1.14...@jscad/stl-deserializer@2.1.15) (2022-04-24)

**Note:** Version bump only for package @jscad/stl-deserializer





## [2.1.14](https://github.com/jscad/OpenJSCAD.org/compare/@jscad/stl-deserializer@2.1.13...@jscad/stl-deserializer@2.1.14) (2022-04-03)

**Note:** Version bump only for package @jscad/stl-deserializer





## [2.1.13](https://github.com/jscad/OpenJSCAD.org/compare/@jscad/stl-deserializer@2.1.12...@jscad/stl-deserializer@2.1.13) (2022-04-03)

**Note:** Version bump only for package @jscad/stl-deserializer





## [2.1.12](https://github.com/jscad/OpenJSCAD.org/compare/@jscad/stl-deserializer@2.1.11...@jscad/stl-deserializer@2.1.12) (2022-03-13)

**Note:** Version bump only for package @jscad/stl-deserializer





## [2.1.11](https://github.com/jscad/OpenJSCAD.org/compare/@jscad/stl-deserializer@2.1.10...@jscad/stl-deserializer@2.1.11) (2022-03-06)

**Note:** Version bump only for package @jscad/stl-deserializer





## [2.1.10](https://github.com/jscad/OpenJSCAD.org/compare/@jscad/stl-deserializer@2.1.9...@jscad/stl-deserializer@2.1.10) (2022-02-19)

**Note:** Version bump only for package @jscad/stl-deserializer





## [2.1.9](https://github.com/jscad/OpenJSCAD.org/compare/@jscad/stl-deserializer@2.1.8...@jscad/stl-deserializer@2.1.9) (2021-12-26)

**Note:** Version bump only for package @jscad/stl-deserializer





## [2.1.8](https://github.com/jscad/OpenJSCAD.org/compare/@jscad/stl-deserializer@2.1.7...@jscad/stl-deserializer@2.1.8) (2021-12-11)

**Note:** Version bump only for package @jscad/stl-deserializer





## [2.1.7](https://github.com/jscad/OpenJSCAD.org/compare/@jscad/stl-deserializer@2.1.6...@jscad/stl-deserializer@2.1.7) (2021-11-07)

**Note:** Version bump only for package @jscad/stl-deserializer





## [2.1.6](https://github.com/jscad/OpenJSCAD.org/compare/@jscad/stl-deserializer@2.1.5...@jscad/stl-deserializer@2.1.6) (2021-10-17)

**Note:** Version bump only for package @jscad/stl-deserializer





## [2.1.5](https://github.com/jscad/OpenJSCAD.org/compare/@jscad/stl-deserializer@2.1.4...@jscad/stl-deserializer@2.1.5) (2021-10-04)

**Note:** Version bump only for package @jscad/stl-deserializer





## [2.1.4](https://github.com/jscad/OpenJSCAD.org/compare/@jscad/stl-deserializer@2.1.3...@jscad/stl-deserializer@2.1.4) (2021-09-27)

**Note:** Version bump only for package @jscad/stl-deserializer





## [2.1.3](https://github.com/jscad/OpenJSCAD.org/compare/@jscad/stl-deserializer@2.1.2...@jscad/stl-deserializer@2.1.3) (2021-09-09)

**Note:** Version bump only for package @jscad/stl-deserializer





## [2.1.2](https://github.com/jscad/OpenJSCAD.org/compare/@jscad/stl-deserializer@2.1.1...@jscad/stl-deserializer@2.1.2) (2021-06-20)

**Note:** Version bump only for package @jscad/stl-deserializer





## [2.1.1](https://github.com/jscad/OpenJSCAD.org/compare/@jscad/stl-deserializer@2.1.0...@jscad/stl-deserializer@2.1.1) (2021-06-11)

**Note:** Version bump only for package @jscad/stl-deserializer





# [2.1.0](https://github.com/jscad/OpenJSCAD.org/compare/@jscad/stl-deserializer@2.0.2...@jscad/stl-deserializer@2.1.0) (2021-06-01)


### Features

* **modeling:** rework math objects to conform with gl-matrix ([#804](https://github.com/jscad/OpenJSCAD.org/issues/804)) ([2e52f10](https://github.com/jscad/OpenJSCAD.org/commit/2e52f104e569f2bb7dd9e1be3d238f471f4d3dfa))





## [2.0.2](https://github.com/jscad/OpenJSCAD.org/compare/@jscad/stl-deserializer@2.0.0-alpha.0...@jscad/stl-deserializer@2.0.2) (2021-04-20)


### Bug Fixes

* **all:** V2 : allow other file types to be loaded into the fake FS of the WEB UI ([#709](https://github.com/jscad/OpenJSCAD.org/issues/709)) ([1d4304a](https://github.com/jscad/OpenJSCAD.org/commit/1d4304ae6b42c51b0526cba369eab1806fe8f274))
* **all:** V2 : several fixes for modeling ([#705](https://github.com/jscad/OpenJSCAD.org/issues/705)) ([62017a4](https://github.com/jscad/OpenJSCAD.org/commit/62017a41214169d6e000f1e0c11aaefdd68e1097))
* **io:** io revisited ([#714](https://github.com/jscad/OpenJSCAD.org/issues/714)) ([22f04f1](https://github.com/jscad/OpenJSCAD.org/commit/22f04f1b2894a82e24952655875e73b74727bf86))
* **modeling:** V2 revisit modifiers ([#773](https://github.com/jscad/OpenJSCAD.org/issues/773)) ([1e28120](https://github.com/jscad/OpenJSCAD.org/commit/1e28120d2b8505dc1882cf3d607296d6fcd5526d))





## [2.0.1](https://github.com/jscad/OpenJSCAD.org/compare/@jscad/stl-deserializer@2.0.0-alpha.0...@jscad/stl-deserializer@2.0.1) (2021-04-15)


### Bug Fixes

* **all:** V2 : allow other file types to be loaded into the fake FS of the WEB UI ([#709](https://github.com/jscad/OpenJSCAD.org/issues/709)) ([1d4304a](https://github.com/jscad/OpenJSCAD.org/commit/1d4304ae6b42c51b0526cba369eab1806fe8f274))
* **all:** V2 : several fixes for modeling ([#705](https://github.com/jscad/OpenJSCAD.org/issues/705)) ([62017a4](https://github.com/jscad/OpenJSCAD.org/commit/62017a41214169d6e000f1e0c11aaefdd68e1097))
* **io:** io revisited ([#714](https://github.com/jscad/OpenJSCAD.org/issues/714)) ([22f04f1](https://github.com/jscad/OpenJSCAD.org/commit/22f04f1b2894a82e24952655875e73b74727bf86))
* **modeling:** V2 revisit modifiers ([#773](https://github.com/jscad/OpenJSCAD.org/issues/773)) ([1e28120](https://github.com/jscad/OpenJSCAD.org/commit/1e28120d2b8505dc1882cf3d607296d6fcd5526d))





# [2.0.0](https://github.com/jscad/OpenJSCAD.org/compare/@jscad/stl-deserializer@2.0.0-alpha.12...@jscad/stl-deserializer@2.0.0) (2021-04-12)

**Note:** Version bump only for package @jscad/stl-deserializer





# [2.0.0-alpha.12](https://github.com/jscad/OpenJSCAD.org/compare/@jscad/stl-deserializer@2.0.0-alpha.11...@jscad/stl-deserializer@2.0.0-alpha.12) (2021-03-07)


### Bug Fixes

* **modeling:** V2 revisit modifiers ([#773](https://github.com/jscad/OpenJSCAD.org/issues/773)) ([1e28120](https://github.com/jscad/OpenJSCAD.org/commit/1e28120d2b8505dc1882cf3d607296d6fcd5526d))





# [2.0.0-alpha.11](https://github.com/jscad/OpenJSCAD.org/compare/@jscad/stl-deserializer@2.0.0-alpha.10...@jscad/stl-deserializer@2.0.0-alpha.11) (2021-02-07)

**Note:** Version bump only for package @jscad/stl-deserializer





# [2.0.0-alpha.10](https://github.com/jscad/OpenJSCAD.org/compare/@jscad/stl-deserializer@2.0.0-alpha.9...@jscad/stl-deserializer@2.0.0-alpha.10) (2021-01-02)

**Note:** Version bump only for package @jscad/stl-deserializer





# [2.0.0-alpha.9](https://github.com/jscad/OpenJSCAD.org/compare/@jscad/stl-deserializer@2.0.0-alpha.8...@jscad/stl-deserializer@2.0.0-alpha.9) (2020-12-04)

**Note:** Version bump only for package @jscad/stl-deserializer





# [2.0.0-alpha.8](https://github.com/jscad/OpenJSCAD.org/compare/@jscad/stl-deserializer@2.0.0-alpha.7...@jscad/stl-deserializer@2.0.0-alpha.8) (2020-11-07)


### Bug Fixes

* **io:** io revisited ([#714](https://github.com/jscad/OpenJSCAD.org/issues/714)) ([22f04f1](https://github.com/jscad/OpenJSCAD.org/commit/22f04f1b2894a82e24952655875e73b74727bf86))





# [2.0.0-alpha.7](https://github.com/jscad/OpenJSCAD.org/compare/@jscad/stl-deserializer@2.0.0-alpha.6...@jscad/stl-deserializer@2.0.0-alpha.7) (2020-10-24)


### Bug Fixes

* **all:** V2 : allow other file types to be loaded into the fake FS of the WEB UI ([#709](https://github.com/jscad/OpenJSCAD.org/issues/709)) ([1d4304a](https://github.com/jscad/OpenJSCAD.org/commit/1d4304ae6b42c51b0526cba369eab1806fe8f274))





# [2.0.0-alpha.6](https://github.com/jscad/OpenJSCAD.org/compare/@jscad/stl-deserializer@2.0.0-alpha.5...@jscad/stl-deserializer@2.0.0-alpha.6) (2020-10-11)


### Bug Fixes

* **all:** V2 : several fixes for modeling ([#705](https://github.com/jscad/OpenJSCAD.org/issues/705)) ([62017a4](https://github.com/jscad/OpenJSCAD.org/commit/62017a41214169d6e000f1e0c11aaefdd68e1097))





# [2.0.0-alpha.5](https://github.com/jscad/OpenJSCAD.org/compare/@jscad/stl-deserializer@2.0.0-alpha.4...@jscad/stl-deserializer@2.0.0-alpha.5) (2020-09-29)

**Note:** Version bump only for package @jscad/stl-deserializer





# [2.0.0-alpha.4](https://github.com/jscad/OpenJSCAD.org/compare/@jscad/stl-deserializer@2.0.0-alpha.3...@jscad/stl-deserializer@2.0.0-alpha.4) (2020-09-28)

**Note:** Version bump only for package @jscad/stl-deserializer





# [2.0.0-alpha.3](https://github.com/jscad/OpenJSCAD.org/compare/@jscad/stl-deserializer@2.0.0-alpha.2...@jscad/stl-deserializer@2.0.0-alpha.3) (2020-09-19)

**Note:** Version bump only for package @jscad/stl-deserializer





# [2.0.0-alpha.2](https://github.com/jscad/OpenJSCAD.org/compare/@jscad/stl-deserializer@2.0.0-alpha.1...@jscad/stl-deserializer@2.0.0-alpha.2) (2020-09-08)

**Note:** Version bump only for package @jscad/stl-deserializer





# [2.0.0-alpha.1](https://github.com/jscad/OpenJSCAD.org/compare/@jscad/stl-deserializer@2.0.0-alpha.0...@jscad/stl-deserializer@2.0.0-alpha.1) (2020-08-19)

**Note:** Version bump only for package @jscad/stl-deserializer





# 2.0.0-alpha.0 (2020-08-13)


### Features

* **stl-deserializer:** updated for V2 (#466)
* **io:** change api to deserialize(options, source)





<a name="0.3.3"></a>
## [0.3.3](https://github.com/jscad/io/compare/@jscad/stl-deserializer@0.3.2...@jscad/stl-deserializer@0.3.3) (2018-11-25)




**Note:** Version bump only for package @jscad/stl-deserializer

<a name="0.3.2"></a>
## [0.3.2](https://github.com/jscad/io/compare/@jscad/stl-deserializer@0.3.1...@jscad/stl-deserializer@0.3.2) (2018-09-02)


### Bug Fixes

* **svg deserializer:** fixed svg-deserializer to work with Inkscape files ([#72](https://github.com/jscad/io/issues/72)) ([f35ea5e](https://github.com/jscad/io/commit/f35ea5e))




<a name="0.3.1"></a>
## [0.3.1](https://github.com/jscad/io/compare/@jscad/stl-deserializer@0.3.0...@jscad/stl-deserializer@0.3.1) (2017-12-14)




**Note:** Version bump only for package @jscad/stl-deserializer

<a name="0.3.0"></a>
# [0.3.0](https://github.com/jscad/io/compare/@jscad/stl-deserializer@0.2.0...@jscad/stl-deserializer@0.3.0) (2017-11-29)


### Features

* add support for a status callback for de/serialization progress ([#49](https://github.com/jscad/io/issues/49)) ([f457cdb](https://github.com/jscad/io/commit/f457cdb))




<a name="0.2.0"></a>
# [0.2.0](https://github.com/jscad/io/compare/@jscad/stl-deserializer@0.1.2...@jscad/stl-deserializer@0.2.0) (2017-11-14)


### Features

* **deserializers:** added csg output capabilities to amf & obj deserializers & basic tests ([#47](https://github.com/jscad/io/issues/47)) ([abf3040](https://github.com/jscad/io/commit/abf3040))




<a name="0.1.2"></a>
## [0.1.2](https://github.com/jscad/io/compare/@jscad/stl-deserializer@0.1.1...@jscad/stl-deserializer@0.1.2) (2017-11-04)




**Note:** Version bump only for package @jscad/stl-deserializer

<a name="0.1.1"></a>
## [0.1.1](https://github.com/jscad/io/compare/@jscad/stl-deserializer@0.1.0...@jscad/stl-deserializer@0.1.1) (2017-10-30)




**Note:** Version bump only for package @jscad/stl-deserializer

<a name="0.1.0"></a>
# [0.1.0](https://github.com/jscad/io/compare/@jscad/stl-deserializer@0.0.5...@jscad/stl-deserializer@0.1.0) (2017-10-15)


### Features

* **stl-deserializer:** add ability to deserialize stl to csg ([#32](https://github.com/jscad/io/issues/32)) ([a90dcf4](https://github.com/jscad/io/commit/a90dcf4))




<a name="0.0.5"></a>
## [0.0.5](https://github.com/jscad/io/compare/@jscad/stl-deserializer@0.0.4...@jscad/stl-deserializer@0.0.5) (2017-10-10)




**Note:** Version bump only for package @jscad/stl-deserializer

<a name="0.0.4"></a>
## 0.0.4 (2017-10-10)




**Note:** Version bump only for package @jscad/stl-deserializer
