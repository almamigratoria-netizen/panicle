
const main = () => require('./binary_stl.stl')

module.exports = { main }
